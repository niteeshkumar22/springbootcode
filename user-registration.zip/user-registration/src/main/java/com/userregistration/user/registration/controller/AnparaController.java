package com.userregistration.user.registration.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.userregistration.user.registration.entity.Anpara;
import com.userregistration.user.registration.service.AnparaClass;

@Controller
public class AnparaController {

	@Autowired
	private AnparaClass anparaClass;
	
	@GetMapping(value ="/anparacity")
	public String AnparaDetailes(Model model,@ModelAttribute("anapara")Anpara anpara) {
		List<Anpara> xyz = anparaClass.getAllAnpara(); 
		model.addAttribute("xyz", xyz);	
		return "anparacity";
	}
	
	
}
