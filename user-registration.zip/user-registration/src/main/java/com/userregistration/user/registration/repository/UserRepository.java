package com.userregistration.user.registration.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.userregistration.user.registration.entity.Userdetailes;

public interface UserRepository extends JpaRepository<Userdetailes, Long> {
	
	@Query(value="select * from user_details ud where id=? ", nativeQuery = true)
	Userdetailes getDataById(Integer id);
	
	@Query(value="delete  from user_details ud where id=? ", nativeQuery = true)
	Userdetailes deleteById(Integer id);
	
	
	
}
