function user (){
	$('#userDetailesid').show();	
}

function usercancle() {
	$('#userDetailesid').hide();
}

function editFunction(element) {
	$('#userDetailesid').hide();
	$('#edituserDetailesid').show();

	var id= element.value;
		$.ajax({
		type: "GET",
		 content : "application/json",
          dataType : "json",
          data : id,
		url:  "/edituser/"+id,		
		success: function(res) {
		$.each(res, function(a, value){	
			
			
			if(a=='firstname'){
		$("#editFirstName").val(value);
		}
			
				if(a=='lastname'){
		$("#editLastName").val(value);
		}
		
			if(a=='age'){
		$("#editage").val(value);
		}
		
			if(a=='address'){
		$("#editAddress").val(value);
		}
		
		if (a == 'id') {
		$("#editUserId").val(value);
		}
		
		/*	if(a=='Birthdate'){
		$("#editdob").val(value);
		}*/
		
		if (a == 'Birthdate') {
		if(value!=null){
	    var myArray = value.substring(0,10).split("-");	       
        var final = myArray[2]+"/"+myArray[1]+"/"+myArray[0];
         }
		$("#editdob").val(final);
		}
			
			if(a=='contact'){
		$("#editcontact").val(value);
		}
		})			
			},
			});
	
 }
 
 function modelhide(){
	$("#edituserDetailesid").hide();
}


//delete 
function deleteEmployee(element) {
    		 var id= element.value;
    		$.ajax({
    			content : "application/json",
    			dataType : "json",
    			data : id,
    			type : 'Get',
    			url :  "/delete/" +id,
    			success : function(res) {
    				 
    			},
    			error : function(e) {
    				console.log(e);
    			},
    			 
    		});
    	}
	