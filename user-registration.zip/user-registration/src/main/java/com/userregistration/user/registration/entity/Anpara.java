package com.userregistration.user.registration.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table (name="AnparaDetails")
@Data
public class Anpara {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ID")
	private Integer id;
	
	@Column(name="NAME")
	private String name;
	
	@Column(name="DISTRICT")
	private String district;
	
	@Column(name="LOCATION")
	private String location;
	
	@Column(name="AREA")
	private Long area;
	
	@Column(name="REGION")
	private String region;
	
	@Column(name="WEATHER")
	private String weather;

}
