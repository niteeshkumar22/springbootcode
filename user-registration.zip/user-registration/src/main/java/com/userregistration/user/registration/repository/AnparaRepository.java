package com.userregistration.user.registration.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.userregistration.user.registration.entity.Anpara;

@Repository
public interface AnparaRepository extends JpaRepository<Anpara, Integer> {
	
	@Query(value="select * from AnparaDetails Where id=?", nativeQuery = true)
	Anpara getbyId(Integer Id);

	@Query (value="select * from AnparaDetails Where id=?", nativeQuery = true)
	Anpara deletebyId(Integer Id);
}
