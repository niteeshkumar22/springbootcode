package com.userregistration.user.registration.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.userregistration.user.registration.entity.Userdetailes;
import com.userregistration.user.registration.repository.UserRepository;

@RestController
public class UserService {
	
	@Autowired UserRepository userrepository;
	
	//save user 
	public  Userdetailes saveUser(@RequestBody Userdetailes user) {
		if(user.getId() != null) {
			Userdetailes sum = userrepository.getDataById(user.getId());
			{
				sum.setFirstname(user.getAddress());
				sum.setAge(user.getAge());
				sum.setBirthdate(user.getBirthdate());
				sum.setContact(user.getContact());
				sum.setFirstname(user.getFirstname());
				sum.setLastname(user.getLastname());
				user = sum;
			}
		}
			else {
				
				
			}
		Userdetailes user34= userrepository.save(user);	
	 return user34;
	}
	
	
	//get all user 
	public List<Userdetailes> getAlluser() {
		return userrepository.findAll();		
	}
	
	//get Single user 
	public Userdetailes getUserdetailes(Integer id,Userdetailes userdetailes) throws Exception  {
		Userdetailes user = userrepository. getDataById(id);		
		return user;
	}
	
	//delete user
	public Userdetailes delete(Integer id) {
		return userrepository.deleteById(id);
	}
	
}
 