package com.userregistration.user.registration.dto;

import java.util.List;

import com.userregistration.user.registration.entity.Userdetailes;

import lombok.Data;

@Data
public class ResponseDto {
	
	private List<Userdetailes> userdetaileslist;

}
