package com.userregistration.user.registration.securityconfiguration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
@EnableWebSecurity
public class SecurityConfig {


	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
	
	@Bean 
	public UserDetailsService userDetailesService() {
		UserDetails firstUser = User
				.withUsername("ashish")
				.password(passwordEncoder().encode("ashish"))
				.roles("admin").build();
		
	 UserDetails secUser=User
			 .withUsername("yadav")
			 .password(passwordEncoder().encode("yadav"))
			 .roles("user").build();

     return new InMemoryUserDetailsManager(firstUser,secUser);
	}
	
	@Bean
	public SecurityFilterChain filterChain(HttpSecurity httpSecurity) throws Exception 
	{
	 httpSecurity.csrf().disable()
	 .authorizeRequests()
	 .antMatchers("/userdetails")
	 .hasRole("admin")
				/*
				 * .antMatchers("/userdetails") .hasRole("user")
				 */
	 .anyRequest()
	 .authenticated()
	 .and()
	 .formLogin()
	 .permitAll()
	 .and()
	 .logout().logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
	 .permitAll();
	 return httpSecurity.build() ;
	
	}
}
 