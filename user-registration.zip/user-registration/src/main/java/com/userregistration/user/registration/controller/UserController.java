package com.userregistration.user.registration.controller;

import java.text.ParseException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.userregistration.user.registration.entity.Userdetailes;
import com.userregistration.user.registration.service.UserService;

@Controller
public class UserController {
	
	@Autowired UserService userservice;
	
	@GetMapping(value ="/userdetails")
	public String  User( Model model, @ModelAttribute("userdetail") Userdetailes userdetailes) {	
		List<Userdetailes> user = userservice.getAlluser();
		model.addAttribute("user",user);
		if(userdetailes.getMessage()!= null) {
		model.addAttribute("SavingConfirmation", userdetailes.getMessage());  
		}
		return "userdetails";
	}
	
	//update
	@ResponseBody
	@GetMapping(value ="/edituser/{id}")
	public Userdetailes UpdateUser(@PathVariable("id") Integer id,Model model, Userdetailes  userdetailes ) throws ParseException {
		try {
			userdetailes = userservice.getUserdetailes(id, userdetailes);
		} catch (Exception e) {			
			e.printStackTrace();
		}
		return userdetailes;
	}
	
	//saving 
	@PostMapping(value ="/saveuser")
	public String  saveUser(@ModelAttribute("userdetail") Userdetailes userdetailes,Model model) {
		userdetailes.setDeleted("0");
		Userdetailes user =userservice.saveUser(userdetailes);
		 
		
		if(user.getFirstname() != null ) {
			userdetailes.setMessage("user detailes update successfully");	
		}
		return "redirect:/userdetails";
	}
	
	@GetMapping("/error")
	public String  geterror() {
		
		return "userdetails";		
	}
	
	
    //delete
	@GetMapping("/delete/{id}")
   public String Delete(@PathVariable("id") Integer id,Model model) {
	   Userdetailes user1 = userservice.delete(id);
	   model.addAttribute("user1", user1);
	   return "delete successfully";
   }





}
