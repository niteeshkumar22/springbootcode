package com.userregistration.user.registration.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name ="user_details")
@Data
@NoArgsConstructor
public class Userdetailes {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name ="ID")
	private Integer id;
	
	@Column(name="FIRSTNAME")
	private String firstname;
	
	@Column(name="LASTNAME")
	private String lastname;
	
	@Column(name="AGE")
	private int age;
	
	@Column(name="BIRTHDATE")
	private String Birthdate;
	
	@Column(name="CONTACT")
	private long contact;
	
	@Column(name="ADDRESS")
	private String address;
	
	@Column(name="deleted")
	private String deleted;
	
	@Transient
	private String message;
	
	
	
	
	

}
 