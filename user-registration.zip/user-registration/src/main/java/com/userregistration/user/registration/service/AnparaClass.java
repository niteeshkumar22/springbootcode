package com.userregistration.user.registration.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import com.userregistration.user.registration.entity.Anpara;
import com.userregistration.user.registration.repository.AnparaRepository;

@Service
public class AnparaClass {
	
	@Autowired
	private AnparaRepository anparaRepository;
	
	//get All List
	public List<Anpara> getAllAnpara() {
		return anparaRepository.findAll();
	}
	
	//Edit 
	public Anpara getAnparaDetails(Integer Id,Anpara anpara) throws Exception {
		Anpara anpara1 = anparaRepository.getbyId(Id);
		return anpara1;
	}
	
	//Delete
	public Anpara getAnparaDetailes(Integer Id,Anpara anpara) throws Exception {
		Anpara atp = anparaRepository.deletebyId(Id);
		return atp;
	}	
	//saving 
	public Anpara saveAnpara(@RequestBody Anpara anpara ) {
		Anpara atpp = anparaRepository.save(anpara);
		return atpp;		
	}
}
